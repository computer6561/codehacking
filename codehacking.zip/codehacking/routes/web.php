<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

use UniSharp\LaravelFilemanager\Lfm;

Route::get('/', function () {
    return view('welcome');
});
Route::auth();
Route::get('/logout', 'Auth\LoginController@logout');
Route::get('/home', 'HomeController@index')->name('home');

Route::get('post/{id}',['as'=>'home.post','uses'=>'HomeController@post']);



Route::group(['middleware'=>['auth','admin']],function (){
    Route::get('/Mail', 'SocialMediaCommunications@sendEmail');
    Route::post('comment/reply','CommentRepliesController@createReply');

    Route::get('account/info','AdminController@info')->name('account.info');
    Route::get('account/setting','AdminController@setting')->name('account.setting');
    Route::post('account/setting','AdminController@updateAccount');

//    Route::get('admin/create/',['PostCommentsController@create'])->name('admin.comments.create');
//    Route::get('admin/store',['PostCommentsController@store'])->name('admin.comments.store');


   /* Route::get('admin/media/upload',['as'=>'admin.media.upload','AdminMediasController@store']);
    Route::get('admin/media/upload',['as'=>'admin.media.upload','AdminMediasController@store']);*/
});
Route::group(['middleware'=>'admin'],function (){

    Route::get('admin/','AdminController@index')->name('admin.index');


    Route::resource('admin/users','AdminUserController',[ 'names'=>[
        'index'=>'admin.users.index',
        'create'=>'admin.users.create',
        'store'=>'admin.users.store',
        'edit'=>'admin.users.edit'
    ]]);

    Route::resource('admin/posts','AdminPostsController',['names'=>[
        'index'=>'admin.posts.index',
        'create'=>'admin.posts.create',
        'store'=>'admin.posts.store',
        'edit'=>'admin.posts.edit'
    ]]);
    Route::resource('admin/categories','AdminCategoriesController',['names'=>[
        'index'=>'admin.categories.index',
        'create'=>'admin.categories.create',
        'store'=>'admin.categories.store',
        'edit'=>'admin.categories.edit'
    ]]);
    Route::resource('admin/media','AdminMediasController',['names'=>[
        'index'=>'admin.media.index',
        'create'=>'admin.media.create',
        'store'=>'admin.media.store',
        'edit'=>'admin.media.edit'
    ]]);

    Route::delete('admin/delete/media','AdminMediasController@deleteMedia');

    Route::get('admin/media/upload',['as'=>'admin.media.upload','AdminMediasController@store']);

    Route::resource('admin/comments','PostCommentsController',['names'=>[
        'index'=>'admin.comments.index',
        'create'=>'admin.comments.create',
        'store'=>'admin.comments.store',
        'edit'=>'admin.comments.edit',
        'show'=>'admin.comments.show'
    ]]);
    Route::resource('admin/comment/replies','CommentRepliesController',['names'=>[
        'index'=>'admin.replies.index',
        'create'=>'admin.replies.create',
        'store'=>'admin.replies.store',
        'edit'=>'admin.replies.edit',
        'show'=>'admin.comment.replies.show'
    ]]);



});
/*
Route::group(['prefix' => 'laravel-filemanager', 'middleware' => ['web', 'auth']], function () {
    Lfm::routes();
});*/
/*
Route::get('/hello', function()
{
    $img = Image::make('D:\xampp\htdocs\codehacking\public\photos/1.jpg')->resize(300, 200);

    return $img->response('jpg');
})*/;