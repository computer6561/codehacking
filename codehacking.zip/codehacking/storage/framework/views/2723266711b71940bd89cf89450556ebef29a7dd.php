<?php $__env->startSection('page-header'); ?>
    <span>User Profile</span>
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row well">
        <div class="col-sm-8">
            <br><br><br>
           <ul class="text-info  font-italic ">
               <li><strong class="col-sm-2">Name   </strong>: <?php echo e($myaccount->name); ?></li>
               <li><strong class="col-sm-2">Email   </strong>:<?php echo e($myaccount->email); ?></li>
               <li><strong class="col-sm-2">Role    </strong>:<?php echo e($myaccount->role->name); ?></li>
               <li><strong class="col-sm-2">User Id</strong>:Udaan/FRM/<?php echo e($myaccount->id); ?></li>
           </ul>
        </div>
        <div class="col-sm-4">
            <img src="<?php echo e($myaccount->photo?$myaccount->photo->file:'http://placehold.it/120x150'); ?>" alt="" class="img-responsive img-thumbnail" height="190" width="160">
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>