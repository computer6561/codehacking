

<?php $__env->startSection('page-header'); ?>
    <span>Media Details</span>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="delete/media" method="post" class="form-inline">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('delete')); ?>

        <div class="form-group">
            <select name="checkboxPhoto" class="form-control">
                <option value="delete" class="form-control-static">Delete</option>
            </select>
        </div>
        <div class="form-group">
            <input type="submit" name="delete_all" value="Submit"  class="btn btn-danger">
        </div>


       <table class="table table-bordered table-striped table-hover">
           <thead>
           <?php if(Session::has('pic_deleted')): ?>
               <tr>
                   <th colspan="4" class="alert text-danger bg-danger text-center">
                              <?php echo e(session('pic_deleted')); ?>

                   </th>
               </tr>
           <?php endif; ?>
             <tr>
               <th>
                   <input type='checkbox' id="options">
               </th>
               <th>Id</th>
               <th>Photos</th>
               <th>Created At</th>
              
             </tr>
           </thead>
           <tbody>
           <?php if(count($photos)): ?>
               <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   <td><input class="checkboxPhoto" type="checkbox" name="checkboxPhoto[]" value="<?php echo e($photo->id); ?>"></td>
                   <td><?php echo e($photo->id); ?></td>
                   <td><img src="<?php echo e($photo->file); ?>" alt=""  class="img-responsive img-rounded" height="50" width="45"></td>
                   <td><?php echo e($photo->created_at); ?></td>
                     
                         
                 </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           </tbody>
         </table>
    </form>
    <div class="col-sm-6 col-sm-offset-3">
        <?php echo e($photos->render()); ?>

    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            $('#options').click(function () {
                if(this.checked){

                    $('.checkboxPhoto').each(function () {
                        this.checked = true;
                    })
                }else{
                    $('.checkboxPhoto').each(function () {
                        this.checked = false;
                    })
                }
            });
        });
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>