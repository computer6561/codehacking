<?php $__env->startSection('page-header'); ?>
        Comments
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <table class="table table-bordered table-striped table-hover">
          <thead>
         
            <tr>
              <th>Id</th>
              <th>Post Id</th>
              <th>Author</th>
              <th>Body</th>
              <th>Posted On</th>
              <th>Post</th>
              <th>Replies</th>
              <th>Status</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php if(count($comments)>0): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($comment->id); ?></td>
                      <td><?php echo e($comment->post_id); ?></td>
                      <td><?php echo e($comment->author); ?></td>
                      <td><?php echo e(str_limit($comment->body,50)); ?></td>
                      <td><?php echo e($comment->created_at); ?></td>
                       <td><a href="<?php echo e(route('home.post',$comment->post->slug)); ?>">view</a></td>
                        <td><a href="<?php echo e(route('admin.comment.replies.show',$comment->id)); ?>">view</a></td>
                       <td>
                        <?php if($comment->is_active==0): ?>
                              <?php echo Form::open(['action' => ['PostCommentsController@update',$comment->id], 'method' => 'PATCH']); ?>

                                  <input type="hidden" value="1" name="is_active">
                                  <?php echo Form::submit('Approve Me',['class'=>'btn btn-xs btn-warning']); ?>

                                <?php echo Form::close(); ?>

                            <?php else: ?>
                               <?php echo Form::open(['action' => ['PostCommentsController@update',$comment->id], 'method' => 'PATCH']); ?>

                               <input type="hidden" value="0" name="is_active">
                               <?php echo Form::submit('Un-Approve',['class'=>'btn btn-xs btn-success']); ?>

                               <?php echo Form::close(); ?>

                          <?php endif; ?>
                       </td>
                       <td>
                           <?php echo Form::open(['action' => ['PostCommentsController@destroy',$comment->id], 'method' => 'DELETE']); ?>

                           <?php echo Form::submit('Delete',['class'=>'btn btn-xs btn-danger']); ?>

                           <?php echo Form::close(); ?>

                       </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          </tbody>
        </table>
        <div class="col-sm-6 col-sm-offset-4">
            <?php echo e($comments->render()); ?>

        </div>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>