<?php $__env->startSection('content'); ?>
    <?php if(Session::has('reply_message')): ?>
        <strong class="text-center alert alert-success">
            <?php echo e(session('reply_message')); ?>

        </strong>
    <?php endif; ?>
    <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Title -->
    <h1><?php echo e(title_case($post->title)); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($post->user->name); ?></a>
    </p>

    <hr>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo e($post->created_at->diffForHumans()); ?></p>

    <hr>

    <!-- Preview Image -->
    <img class="img-responsive" src="<?php echo e(($post->photo)?$post->photo->file:null); ?>" alt="" width="280" height="100">

    <hr>

    <!-- Post Content -->
     <p><?php echo $post->body; ?></p>
    <hr>
    
    <!-- Blog Comments -->
<?php if(Auth::check()): ?>
    <!-- Comments Form -->
    <div class="well">
        <h4>Leave a Comment:</h4>
           <?php echo Form::open(['action' => ['PostCommentsController@store'], 'method' => 'post']); ?>


                 <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                 <div class="form-group">
                    <?php echo Form::textarea('body',null,['class'=>'form-control','placeholder'=>'write comment','rows'=>4]); ?>

                 </div>
                 <div class="form-group">
                   <?php echo Form::submit('CommentRequest',['class'=>'btn btn-info']); ?>

                   <strong class="text-center text-success">
                       <?php if(Session('comment_post')): ?>
                           <?php echo e(session('comment_post')); ?>

                       <?php endif; ?>
                   </strong>
                 </div>
             <?php echo Form::close(); ?>

    </div>
<?php endif; ?>

    <hr>

    <!-- Posted Comments -->
<?php if(count($comments)>0): ?>

    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="media comment-media">
                <div class="comment-button pull-left">
                    <img class="media-object img-responsive img-rounded" src="<?php echo e($comment->post->user->photo?$comment->post->user->photo->file:'http://placehold.it/64x64'); ?>" alt="" height="50" width="44">


                 <i class="fa fa-reply toggle-comment-body" id="<?php echo e($comment->id); ?>" ></i>
                </div>

                <div class="media-body ">
                    <h4 class="media-heading"><?php echo e($comment->author); ?>

                        <small><?php echo e(Carbon\Carbon::parse($comment->created_at)->format('d-M-Y, h:m:s A')); ?></small>
                    </h4>
                     <p>
                         <?php echo e($comment->body); ?>

                     </p>
                    <div class="comment-reply-media" id="comment<?php echo e($comment->id); ?>">

                    <?php if(count($comment->replies)>0): ?>
                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($reply->is_active==1): ?>
                    <div class="media ">
                        <a class="pull-left" href="#">
                            <img class="media-object img-responsive img-rounded" src="<?php echo e($reply->comment->post->user->photo?$reply->comment->post->user->photo->file:'http://placehold.it/50x50'); ?>" alt="" height="50" width="44">
                        </a>
                        <div class="media-body ">
                            <h4 class="media-heading"><?php echo e($reply->author); ?>

                                <small><?php echo e(Carbon\Carbon::parse($reply->created_at)->format('d-M-Y, h:m:s A')); ?></small>
                            </h4>
                            <p>
                                <?php echo e($reply->body); ?>

                            </p>
                        </div>


                    </div>
                       <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
                        <?php echo Form::open(['action' => ['CommentRepliesController@createReply'], 'method' => 'post']); ?>

                        <input type='hidden' name="comment_id" value="<?php echo e($comment->id); ?>">
                        <div class="form-group">
                            <?php echo Form::label('body','Reply : '); ?>

                            <?php echo Form::textarea('body',null,['class'=>'form-control','placeholder'=>'write your reply here','rows'=>2]); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::submit('Post',['class'=>'btn btn-sm btn-success']); ?>


                        </div>
                        <?php echo Form::close(); ?>

             </div>
        </div>
    </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
      $('.toggle-comment-body').click(function(){
          $('#comment'+$(this)[0].id).slideToggle('slow');
         // alert('hello');
      });
    </script>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.blog-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>