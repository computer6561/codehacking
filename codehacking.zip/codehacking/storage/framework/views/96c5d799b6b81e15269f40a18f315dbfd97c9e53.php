<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Codehacking</title>

    <!-- Fonts -->
    <!-- Styles -->

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/landing-page.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/simple-line-icons.css')); ?>" rel="stylesheet">
    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
        .nav a{
            margin: 10px 15px;
        }
        .dropdown-menu li{
            margin-left: 5px;
        }
    </style>
</head>
<body id="">
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">CodeHacking</a>
        </div>
        <?php if(Auth::guest()): ?>
           <div class="pull-right nav">
               <a href="<?php echo e(url('/login')); ?>" class="">Login</a>
               <a href="<?php echo e(url('/register')); ?>">Register</a>
           </div>

        <?php else: ?>
            <div class="dropdown pull-right">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <ul class="dropdown-menu" role="menu">
                    <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa col-sm-offset-1 fa-btn fa-sign-out"></i>Logout</a></li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</nav>


    <?php echo $__env->yieldContent('content'); ?>

    <!-- JavaScripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" integrity="sha384-I6F5OKECLVtK/BL+8iSLDEHowSAfUo76ZL9+kGAgTRdiByINKJaqTPH/QVNS1VDb" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    
</body>
</html>
