
<?php $__env->startSection('page-header'); ?>
   Edit Posts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <?php echo $__env->make('includes.tinyeditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="col-sm-3">
      <img src="../../<?php echo e($post->user->photo->file); ?>" class="img-rounded img-responsive">
      <div class="row text-center">
         <h4 class="text-uppercase text-success"><?php echo e($post->user->name); ?></h4>
         <h5><?php echo e($post->user->email); ?></h5>
      </div>
   </div>
   <div class="col-sm-9">
      <?php echo Form::model($post,['action' => ['AdminPostsController@update',$post->id], 'method' => 'PATCH','files'=>true]); ?>

      <div class="form-group">
         <?php echo Form::label('category_id','Category : '); ?>

         <?php echo Form::select('category_id',array(''=>'Choose Category')+$categories,null,['class'=>'form-control']); ?>

      </div>
      <div class="form-group">
         <?php echo Form::label('title','Title : '); ?>

         <?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'title']); ?>

      </div>
      <div class="form-group">
         <?php echo Form::label('body','Message : '); ?>

         <?php echo Form::textarea('body',null,['class'=>'form-control tinyeditor','rows'=>5,'placeholder'=>'message']); ?>

      </div>
      <div class="form-group">
         <?php echo Form::label('photo_id','Picture : '); ?>

         <?php echo Form::file('photo_id',['class'=>'form-control']); ?>

      </div>
      <div class="form-group">
         <?php echo Form::submit('Submit',['class'=>'btn btn-info']); ?>

      </div>
      <?php echo Form::close(); ?>

   </div>
   
   <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>