<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('includes.home_front_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<!-- Navigation -->
  <?php echo $__env->make('includes.home_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Page Content -->

   <?php echo $__env->yieldContent('content'); ?>

    <hr>

    <!-- Footer -->
     <?php echo $__env->make('includes.home_front_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- /.container -->

</body>

</html>
