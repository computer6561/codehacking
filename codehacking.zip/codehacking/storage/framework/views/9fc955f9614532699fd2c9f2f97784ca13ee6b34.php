<?php $__env->startSection('page-header'); ?>
    <span>User Account Setting</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-sm-3 text-center">
        <img src="<?php echo e($user->photo?$user->photo->file:'http://placehold.it/150x200'); ?>" alt="" class="img-responsive img-rounded" height="160" width="140">
        <div class="row">

        </div>
    </div>
    <div class="col-sm-9 well">

        <?php echo Form::model($user,['action' => ['AdminController@updateAccount'], 'method' => 'post','files'=>true]); ?>

        <div class="form-group">
            <?php echo Form::label('name','Name : '); ?>

            <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('email','Email : '); ?>

            <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'enter email']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('password','Password : '); ?>

            <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'enter password']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('file','Photo : '); ?>

            <?php echo Form::file('file',['class'=>'form-control','placeholder'=>'title']); ?>

        </div>
        <div class="form-group text-center">
            <?php echo Form::submit('Update',['class'=>'btn btn-info col-sm-3']); ?>

        </div>
        <?php echo Form::close(); ?>

        <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>