<?php $__env->startSection('page-header'); ?>
    Posts Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <table class="table table-bordered table-striped table-hover">
         <thead>
         <?php if(Session::has('deleted_post')||Session::has('updated_post')): ?>
         <tr>
             <th colspan="7" class="bg-warning text-success text-center"><?php echo e(session('deleted_post')); ?><?php echo e(session('updated_post')); ?></th>
         </tr>
         <?php endif; ?>
           <tr>
             <th>Id</th>
             <th>Picture</th>
             <th>Category</th>
             <th>Name</th>
             <th>Title</th>
             <th>Message</th>
             <th>Comments</th>
             <th>Created On</th>
             <th>Delete</th>
           </tr>
         </thead>
         <tbody>
          <?php if(count($posts)>0): ?>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                     <td><?php echo e($post->id); ?></td>
                     <td>
                         <img src="<?php echo e(($post->photo_id!=0)?$post->photo->file:'http://placehold.it/50x50'); ?>" alt="" class="img-responsive img-rounded" height="50" width="40">
                     </td>
                      <td><?php echo e($post->category->name); ?></td>
                     <td><?php echo e($post->user->name); ?></td>
                     <td> <a href="<?php echo e(route('home.post', $post->slug)); ?>"><?php echo e($post->title); ?> </a></td>
                     <td><a href="<?php echo e(route('admin.posts.edit', $post->id )); ?>"><?php echo e(str_limit($post->body,50)); ?></a></td>
                       <td><a href="<?php echo e(route('admin.comments.show', $post->id )); ?>">view</a></td>
                     <td><?php echo e($post->created_at); ?></td>
                      <td>
                            <?php echo Form::open(['action' => ['AdminPostsController@destroy',$post->id], 'method' => 'DELETE']); ?>

                                  <div class="form-group">
                                      <?php echo Form::submit('Delete',['class'=>'btn btn-sm btn-danger']); ?>

                                  </div>
                              <?php echo Form::close(); ?>

                         
                      </td>
                   </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
         </tbody>
       </table>

     <div class="row">
         <div class="col-sm-6 col-sm-offset-5">
             <?php echo e($posts->render()); ?>

         </div>
     </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>