
<?php $__env->startSection('page-header'); ?>
    Create Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php echo Form::open(['action' => ['AdminCategoriesController@store'], 'method' => 'post']); ?>

    <div class="form-group">
        <?php echo Form::label('name','Name : '); ?>

        <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Add Category',['class'=>'btn btn-info']); ?>

    </div>
    <?php echo Form::close(); ?>


    <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>