
<?php $__env->startSection('page-header'); ?>
    <span>Edit Users Details</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="col-sm-3">
        <img src="../../<?php echo e($user->photo?$user->photo->file:'http://placehold.io/400x400'); ?>" alt="" class="img-responsive img-rounded">
        <div class="row">

        </div>
    </div>
     <div class="col-sm-9">

    <?php echo Form::model($user,['action' => ['AdminUserController@update',$user->id], 'method' => 'patch','files'=>true]); ?>

    <div class="form-group">
        <?php echo Form::label('name','Name : '); ?>

        <?php echo Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('email','Email : '); ?>

        <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'enter email']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('role_id','Role : '); ?>

        <?php echo Form::select('role_id',array(''=>'Choose Options')+$roles,null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('is_active','Status : '); ?>

        <?php echo Form::select('is_active',array(0=>'Not Active',1=>'Active'),null,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('password','Password : '); ?>

        <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'enter password']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('file','Photo : '); ?>

        <?php echo Form::file('file',['class'=>'form-control','placeholder'=>'title']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::submit('Update',['class'=>'btn btn-info col-sm-3']); ?>

    </div>
    <?php echo Form::close(); ?>

         <?php echo Form::open(['action' => ['AdminUserController@destroy',$user->id ], 'method' => 'DELETE']); ?>


         <div class="form-group text-center">
             <?php echo Form::submit('Delete',['class'=>'btn btn-danger col-sm-3 col-sm-offset-6']); ?>

         </div>
         <?php echo Form::close(); ?>

    <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>