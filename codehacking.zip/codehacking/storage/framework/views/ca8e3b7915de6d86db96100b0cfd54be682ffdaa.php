

<?php $__env->startSection('page-header'); ?>
    Post Comments Replies
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-bordered table-striped table-hover">
        <thead>
        
        <tr>
            <th>Id</th>
            <th>Post Id</th>
            <th>Comment Id</th>
            <th>Author</th>
            <th>Body</th>
            <th>Posted On</th>
            <th>Status</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php if(count($replies)>0): ?>
            <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($reply->id); ?></td>
                    <td><?php echo e($reply->comment->post->id); ?></td>
                    <td><?php echo e($reply->comment_id); ?></td>
                    <td><?php echo e($reply->author); ?></td>
                    <td><?php echo e(str_limit($reply->body,50)); ?></td>
                    <td><?php echo e($reply->created_at); ?></td>
                    <td>
                        <?php if($reply->is_active==0): ?>
                            <?php echo Form::open(['action' => ['CommentRepliesController@update',$reply->id], 'method' => 'PATCH']); ?>

                            <input type="hidden" value="1" name="is_active">
                            <?php echo Form::submit('Approve Me',['class'=>'btn btn-xs btn-warning']); ?>

                            <?php echo Form::close(); ?>

                        <?php else: ?>
                            <?php echo Form::open(['action' => ['CommentRepliesController@update',$reply->id], 'method' => 'PATCH']); ?>

                            <input type="hidden" value="0" name="is_active">
                            <?php echo Form::submit('Un-Approve',['class'=>'btn btn-xs btn-success']); ?>

                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo Form::open(['action' => ['CommentRepliesController@destroy',$reply->id], 'method' => 'DELETE']); ?>

                        <?php echo Form::submit('Delete',['class'=>'btn btn-xs btn-danger']); ?>

                        <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="col-sm-6 col-sm-offset-4">
        <?php echo e($replies->render()); ?>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>