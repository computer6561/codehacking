
<?php $__env->startSection('page-header'); ?>
    Create Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.tinyeditor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::open(['action' => ['AdminPostsController@store'], 'method' => 'post','files'=>true]); ?>

              <div class="form-group">
                  <?php echo Form::label('category_id','Category : '); ?>

                  <?php echo Form::select('category_id',array(''=>'Choose Category')+$categories,null,['class'=>'form-control']); ?>

              </div>
              <div class="form-group">
                 <?php echo Form::label('title','Title : '); ?>

                 <?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'title']); ?>

              </div>
              <div class="form-group">
                 <?php echo Form::label('body','Message : '); ?>

                 <?php echo Form::textarea('body',null,['class'=>'form-control tinyeditor','rows'=>5,'placeholder'=>'message']); ?>

              </div>
                  <div class="form-group">
                 <?php echo Form::label('photo_id','Picture : '); ?>

                 <?php echo Form::file('photo_id',['class'=>'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::submit('Submit',['class'=>'btn btn-info']); ?>

              </div>
          <?php echo Form::close(); ?>

     <?php echo $__env->make('includes.form_errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>