
<?php $__env->startSection('page-header'); ?>
    <span>Categories</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
        <?php if(Session::has('deleted_category')): ?>
            <tr>
                <th colspan="8" class="text-danger text-center bg-danger"><?php echo e(session('deleted_category')); ?></th>
            </tr>
        <?php endif; ?>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Created On</th>
            <th>Updated On</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php if($categories): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->id); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td><?php echo e($category->created_at); ?></td>
                    <td><?php echo e($category->updated_at->diffForHumans()); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.categories.edit',$category->id)); ?>"><i class="fa fa-edit"></i></a>
                    </td>
                    <td>
                         <?php echo Form::open(['action' => ['AdminCategoriesController@destroy',$category->id], 'method' => 'DELETE']); ?>

                              <div class="form-group">
                                <?php echo Form::submit('Delete',['class'=>'btn btn-xs btn-danger']); ?>

                              </div>
                          <?php echo Form::close(); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="col-sm-6 col-sm-offset-4">
        <?php echo e($categories->render()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>