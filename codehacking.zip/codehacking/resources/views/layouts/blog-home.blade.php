<!DOCTYPE html>
<html lang="en">

@include('includes.home_front_header')
<body>

<!-- Navigation -->
  @include('includes.home_nav')

<!-- Page Content -->

   @yield('content')

    <hr>

    <!-- Footer -->
     @include('includes.home_front_footer')
<!-- /.container -->

</body>

</html>
