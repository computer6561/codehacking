@extends('layouts.blog-home')

@section('content')
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">

                <h1 class="page-header">
                   Posts
                    <small>Message</small>
                </h1>
                @if($posts)
                <!-- First Blog Post -->
                  @foreach($posts as $post)
                <h2>
                    <a href="#">{{$post->title}}</a>
                </h2>
                <p class="lead">
                    by <a href="index.php">{{ $post->user->name }}</a>
                </p>
                <p>
                    <span class="glyphicon glyphicon-time"></span>
                    Posted on {{Carbon\Carbon::parse($post->created_at)->format('d-M-Y, h:m:s A')}}</p>
                <hr>
                        <img class="media-object img-responsive img-rounded" src="{{$post->photo?str_replace_first('../','',$post->photo->file):'http://placehold.it/120x80'}}" alt="" width="300px">
                <hr>
                <p>
                   {!!  str_limit($post->body,200) !!}
                </p>
                <a class="btn btn-primary" href="post/{{$post->slug}}">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
                    @endforeach
                @endif
                <!-- Pager -->

                 <div class="text-center text-nowrap">{{$posts->render()}}</div>

            </div>

            <!-- Blog Sidebar Widgets Column -->
        @include('includes.home_side_nav')
        <!-- Side Widget Well -->
        </div>

    </div>
@endsection
