@extends('layouts.blog-post')

@section('content')
    @if(Session::has('reply_message'))
        <strong class="text-center alert alert-success">
            {{session('reply_message')}}
        </strong>
    @endif
    @include('includes.form_errors')
    <!-- Title -->
    <h1>{{title_case($post->title)}}</h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#">{{$post->user->name}}</a>
    </p>

    <hr>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> Posted on {{$post->created_at->diffForHumans()}}</p>

    <hr>

    <!-- Preview Image -->
    <img class="img-responsive" src="{{($post->photo)?$post->photo->file:null}}" alt="" width="280" height="100">

    <hr>

    <!-- Post Content -->
     <p>{!! $post->body  !!}</p>
    <hr>
    {{--<i class="fa fa-thumbs-up"></i>
    <i class="fa fa-thumbs-down"></i>
    <i class="fa fa-comment" ></i>
    <hr>--}}
    <!-- Blog Comments -->
@if(Auth::check())
    <!-- Comments Form -->
    <div class="well">
        <h4>Leave a Comment:</h4>
           {!! Form::open(['action' => ['PostCommentsController@store'], 'method' => 'post']) !!}

                 <input type="hidden" name="post_id" value="{{$post->id}}">
                 <div class="form-group">
                    {!! Form::textarea('body',null,['class'=>'form-control','placeholder'=>'write comment','rows'=>4]) !!}
                 </div>
                 <div class="form-group">
                   {!! Form::submit('CommentRequest',['class'=>'btn btn-info']) !!}
                   <strong class="text-center text-success">
                       @if(Session('comment_post'))
                           {{session('comment_post')}}
                       @endif
                   </strong>
                 </div>
             {!! Form::close() !!}
    </div>
@endif

    <hr>

    <!-- Posted Comments -->
@if(count($comments)>0)

    @foreach($comments as $comment)
            <div class="media comment-media">
                <div class="comment-button pull-left">
                    <img class="media-object img-responsive img-rounded" src="{{$comment->post->user->photo?$comment->post->user->photo->file:'http://placehold.it/64x64'}}" alt="" height="50" width="44">
{{--   <img src="{{Auth::user()->gravatar}}" height="50" >--}}

                 <i class="fa fa-reply toggle-comment-body" id="{{$comment->id}}" ></i>
                </div>

                <div class="media-body ">
                    <h4 class="media-heading">{{$comment->author}}
                        <small>{{Carbon\Carbon::parse($comment->created_at)->format('d-M-Y, h:m:s A')}}</small>
                    </h4>
                     <p>
                         {{$comment->body}}
                     </p>
                    <div class="comment-reply-media" id="comment{{$comment->id}}">

                    @if(count($comment->replies)>0)
                        @foreach($comment->replies as $reply)
                            @if($reply->is_active==1)
                    <div class="media ">
                        <a class="pull-left" href="#">
                            <img class="media-object img-responsive img-rounded" src="{{$reply->comment->post->user->photo?$reply->comment->post->user->photo->file:'http://placehold.it/50x50'}}" alt="" height="50" width="44">
                        </a>
                        <div class="media-body ">
                            <h4 class="media-heading">{{$reply->author}}
                                <small>{{Carbon\Carbon::parse($reply->created_at)->format('d-M-Y, h:m:s A')}}</small>
                            </h4>
                            <p>
                                {{$reply->body}}
                            </p>
                        </div>


                    </div>
                       @endif
                @endforeach
              @endif
                        {!! Form::open(['action' => ['CommentRepliesController@createReply'], 'method' => 'post']) !!}
                        <input type='hidden' name="comment_id" value="{{$comment->id}}">
                        <div class="form-group">
                            {!! Form::label('body','Reply : ') !!}
                            {!! Form::textarea('body',null,['class'=>'form-control','placeholder'=>'write your reply here','rows'=>2]) !!}
                        </div>
                        <div class="form-group">
                            {!! Form::submit('Post',['class'=>'btn btn-sm btn-success']) !!}

                        </div>
                        {!! Form::close() !!}
             </div>
        </div>
    </div>
   @endforeach
@endif
@endsection
@section('script')
    <script type="text/javascript">
      $('.toggle-comment-body').click(function(){
          $('#comment'+$(this)[0].id).slideToggle('slow');
         // alert('hello');
      });
    </script>
    @endsection



