@extends('layouts.admin')

@section('page-header')
    Post Comments Replies
@endsection

@section('content')
    <table class="table table-bordered table-striped table-hover">
        <thead>
        {{-- <tr>
             <th colspan="6"></th>
         </tr>--}}
        <tr>
            <th>Id</th>
            <th>Post Id</th>
            <th>Comment Id</th>
            <th>Author</th>
            <th>Body</th>
            <th>Posted On</th>
            <th>Status</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        @if(count($replies)>0)
            @foreach($replies as $reply)
                <tr>
                    <td>{{$reply->id}}</td>
                    <td>{{$reply->comment->post->id}}</td>
                    <td>{{$reply->comment_id}}</td>
                    <td>{{$reply->author}}</td>
                    <td>{{str_limit($reply->body,50)}}</td>
                    <td>{{$reply->created_at}}</td>
                    <td>
                        @if($reply->is_active==0)
                            {!! Form::open(['action' => ['CommentRepliesController@update',$reply->id], 'method' => 'PATCH']) !!}
                            <input type="hidden" value="1" name="is_active">
                            {!! Form::submit('Approve Me',['class'=>'btn btn-xs btn-warning']) !!}
                            {!! Form::close() !!}
                        @else
                            {!! Form::open(['action' => ['CommentRepliesController@update',$reply->id], 'method' => 'PATCH']) !!}
                            <input type="hidden" value="0" name="is_active">
                            {!! Form::submit('Un-Approve',['class'=>'btn btn-xs btn-success']) !!}
                            {!! Form::close() !!}
                        @endif
                    </td>
                    <td>
                        {!! Form::open(['action' => ['CommentRepliesController@destroy',$reply->id], 'method' => 'DELETE']) !!}
                        {!! Form::submit('Delete',['class'=>'btn btn-xs btn-danger']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
        @endif
        </tbody>
    </table>
    <div class="col-sm-6 col-sm-offset-4">
        {{$replies->render()}}
    </div>
@endsection

