@extends('layouts.admin')

@section('page-header')
    Comments
@endsection

@section('content')
    <table class="table table-bordered table-striped table-hover">
        <thead>
        {{-- <tr>
             <th colspan="6"></th>
         </tr>--}}
        <tr>
            <th>Id</th>
            <th>Post Id</th>
            <th>Author</th>
            <th>Body</th>
            <th>Posted On</th>
            <th>View Post</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        @if(count($comments)>0)
            @foreach($comments as $comment)
                <tr>
                    <td>{{$comment->id}}</td>
                    <td>{{$comment->post_id}}</td>
                    <td>{{$comment->author}}</td>
                    <td>{{str_limit($comment->body,50)}}</td>
                    <td>{{$comment->created_at}}</td>
                    <td><a href="{{route('home.post',$comment->post->slug)}}">view</a></td>
                    <td>
                        {!! Form::open(['action' => ['PostCommentsController@destroy',$comment->id], 'method' => 'DELETE']) !!}
                        {!! Form::submit('Delete',['class'=>'btn btn-xs btn-danger']) !!}
                        {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
        @endif
        </tbody>
    </table>

@endsection

