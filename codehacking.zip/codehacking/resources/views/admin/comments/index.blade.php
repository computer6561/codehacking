@extends('layouts.admin')

@section('page-header')
        Comments
    @endsection

@section('content')
      <table class="table table-bordered table-striped table-hover">
          <thead>
         {{-- <tr>
              <th colspan="6"></th>
          </tr>--}}
            <tr>
              <th>Id</th>
              <th>Post Id</th>
              <th>Author</th>
              <th>Body</th>
              <th>Posted On</th>
              <th>Post</th>
              <th>Replies</th>
              <th>Status</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            @if(count($comments)>0)
                @foreach($comments as $comment)
                    <tr>
                      <td>{{$comment->id}}</td>
                      <td>{{$comment->post_id}}</td>
                      <td>{{$comment->author}}</td>
                      <td>{{str_limit($comment->body,50)}}</td>
                      <td>{{$comment->created_at}}</td>
                       <td><a href="{{route('home.post',$comment->post->slug)}}">view</a></td>
                        <td><a href="{{route('admin.comment.replies.show',$comment->id)}}">view</a></td>
                       <td>
                        @if($comment->is_active==0)
                              {!! Form::open(['action' => ['PostCommentsController@update',$comment->id], 'method' => 'PATCH']) !!}
                                  <input type="hidden" value="1" name="is_active">
                                  {!! Form::submit('Approve Me',['class'=>'btn btn-xs btn-warning']) !!}
                                {!! Form::close() !!}
                            @else
                               {!! Form::open(['action' => ['PostCommentsController@update',$comment->id], 'method' => 'PATCH']) !!}
                               <input type="hidden" value="0" name="is_active">
                               {!! Form::submit('Un-Approve',['class'=>'btn btn-xs btn-success']) !!}
                               {!! Form::close() !!}
                          @endif
                       </td>
                       <td>
                           {!! Form::open(['action' => ['PostCommentsController@destroy',$comment->id], 'method' => 'DELETE']) !!}
                           {!! Form::submit('Delete',['class'=>'btn btn-xs btn-danger']) !!}
                           {!! Form::close() !!}
                       </td>
                    </tr>
                @endforeach
            @endif
          </tbody>
        </table>
        <div class="col-sm-6 col-sm-offset-4">
            {{$comments->render()}}
        </div>
    @endsection

