@extends('layouts.admin')

@section('page-header')
    <span>User Profile</span>
    @endsection


@section('content')
    <div class="row well">
        <div class="col-sm-8">
            <br><br><br>
           <ul class="text-info  font-italic ">
               <li><strong class="col-sm-2">Name   </strong>: {{$myaccount->name}}</li>
               <li><strong class="col-sm-2">Email   </strong>:{{$myaccount->email}}</li>
               <li><strong class="col-sm-2">Role    </strong>:{{$myaccount->role->name}}</li>
               <li><strong class="col-sm-2">User Id</strong>:Udaan/FRM/{{$myaccount->id}}</li>
           </ul>
        </div>
        <div class="col-sm-4">
            <img src="{{$myaccount->photo?$myaccount->photo->file:'http://placehold.it/120x150'}}" alt="" class="img-responsive img-thumbnail" height="190" width="160">
        </div>
    </div>

@stop

@section('script')

@endsection