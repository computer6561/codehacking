@extends('layouts.admin')
@section('page-header')
   Edit Posts
@endsection
@section('content')
   @include('includes.tinyeditor')
   <div class="col-sm-3">
      <img src="../../{{$post->user->photo->file}}" class="img-rounded img-responsive">
      <div class="row text-center">
         <h4 class="text-uppercase text-success">{{$post->user->name}}</h4>
         <h5>{{$post->user->email}}</h5>
      </div>
   </div>
   <div class="col-sm-9">
      {!! Form::model($post,['action' => ['AdminPostsController@update',$post->id], 'method' => 'PATCH','files'=>true]) !!}
      <div class="form-group">
         {!! Form::label('category_id','Category : ') !!}
         {!! Form::select('category_id',array(''=>'Choose Category')+$categories,null,['class'=>'form-control']) !!}
      </div>
      <div class="form-group">
         {!! Form::label('title','Title : ') !!}
         {!! Form::text('title',null,['class'=>'form-control','placeholder'=>'title']) !!}
      </div>
      <div class="form-group">
         {!! Form::label('body','Message : ') !!}
         {!! Form::textarea('body',null,['class'=>'form-control tinyeditor','rows'=>5,'placeholder'=>'message']) !!}
      </div>
      <div class="form-group">
         {!! Form::label('photo_id','Picture : ') !!}
         {!! Form::file('photo_id',['class'=>'form-control']) !!}
      </div>
      <div class="form-group">
         {!! Form::submit('Submit',['class'=>'btn btn-info']) !!}
      </div>
      {!! Form::close() !!}
   </div>
   
   @include('includes.form_errors')
@endsection