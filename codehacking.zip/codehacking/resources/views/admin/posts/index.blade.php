@extends('layouts.admin')
@section('page-header')
    Posts Details
@endsection
@section('content')
     <table class="table table-bordered table-striped table-hover pull">
         <thead>
         @if(Session::has('deleted_post')||Session::has('updated_post'))
         <tr>
             <th colspan="7" class="bg-warning text-success text-center">{{session('deleted_post')}}{{session('updated_post')}}</th>
         </tr>
         @endif
           <tr>
             <th>Id</th>
             <th>Picture</th>
             <th>Category</th>
             <th>Name</th>
             <th>Title</th>
             <th>Message</th>
             <th>Comments</th>
             <th>Created On</th>
             <th>Delete</th>
           </tr>
         </thead>
         <tbody>
          @if(count($posts)>0)
              @foreach($posts as $post)
                   <tr>
                     <td>{{$post->id}}</td>
                     <td>
                         <img src="{{($post->photo_id!=0)?$post->photo->file:'http://placehold.it/50x50'}}" alt="" class="img-responsive img-rounded" height="50" width="40">
                     </td>
                      <td>{{$post->category->name}}</td>
                     <td>{{$post->user->name}}</td>
                     <td> <a href="{{route('home.post', $post->slug)}}">{{$post->title}} </a></td>
                     <td><a href="{{route('admin.posts.edit', $post->id )}}">{{str_limit($post->body,50)}}</a></td>
                       <td><a href="{{route('admin.comments.show', $post->id )}}">view</a></td>
                     <td>{{$post->created_at}}</td>
                      <td>
                            {!! Form::open(['action' => ['AdminPostsController@destroy',$post->id], 'method' => 'DELETE']) !!}
                                  <div class="form-group">
                                      {!! Form::submit('Delete',['class'=>'btn btn-sm btn-danger']) !!}
                                  </div>
                              {!! Form::close() !!}
                         {{-- <a ><i class="fa fa-trash" aria-hidden="true" onclick="document.getElementById('submit').setAttribute('type','submit').submit()"></i></a>--}}
                      </td>
                   </tr>
              @endforeach
          @endif
         </tbody>
       </table>

     <div class="row">
         <div class="col-sm-6 col-sm-offset-5">
             {{$posts->render()}}
         </div>
     </div>
    @endsection