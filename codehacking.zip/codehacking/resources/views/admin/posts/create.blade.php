@extends('layouts.admin')
@section('page-header')
    Create Details
@endsection

@section('content')
    @include('includes.tinyeditor')
        {!! Form::open(['action' => ['AdminPostsController@store'], 'method' => 'post','files'=>true]) !!}
              <div class="form-group">
                  {!! Form::label('category_id','Category : ') !!}
                  {!! Form::select('category_id',array(''=>'Choose Category')+$categories,null,['class'=>'form-control']) !!}
              </div>
              <div class="form-group">
                 {!! Form::label('title','Title : ') !!}
                 {!! Form::text('title',null,['class'=>'form-control','placeholder'=>'title']) !!}
              </div>
              <div class="form-group">
                 {!! Form::label('body','Message : ') !!}
                 {!! Form::textarea('body',null,['class'=>'form-control tinyeditor','rows'=>5,'placeholder'=>'message']) !!}
              </div>
                  <div class="form-group">
                 {!! Form::label('photo_id','Picture : ') !!}
                 {!! Form::file('photo_id',['class'=>'form-control']) !!}
              </div>
              <div class="form-group">
                {!! Form::submit('Submit',['class'=>'btn btn-info']) !!}
              </div>
          {!! Form::close() !!}
     @include('includes.form_errors')
@endsection
