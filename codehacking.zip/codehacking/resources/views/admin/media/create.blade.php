@extends('layouts.admin')

@section('page-header')
       <span>Media Upload</span>
    @endsection
@section('style')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.css" />
    @endsection
@section('content')
          {!! Form::open(['action' => ['AdminMediasController@store' ], 'method' => 'post', 'class'=>'dropzone']) !!}

            {!! Form::close() !!}
    @endsection

@section('script')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.js"></script>
    @endsection