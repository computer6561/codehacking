@extends('layouts.admin')

@section('page-header')
    <span>Media Details</span>
    @endsection

@section('content')

    <form action="delete/media" method="post" class="form-inline">
        {{csrf_field()}}
        {{method_field('delete')}}
        <div class="form-group">
            <select name="checkboxPhoto" class="form-control">
                <option value="delete" class="form-control-static">Delete</option>
            </select>
        </div>
        <div class="form-group">
            <input type="submit" name="delete_all" value="Submit"  class="btn btn-danger">
        </div>


       <table class="table table-bordered table-striped table-hover">
           <thead>
           @if(Session::has('pic_deleted'))
               <tr>
                   <th colspan="4" class="alert text-danger bg-danger text-center">
                              {{session('pic_deleted')}}
                   </th>
               </tr>
           @endif
             <tr>
               <th>
                   <input type='checkbox' id="options">
               </th>
               <th>Id</th>
               <th>Photos</th>
               <th>Created At</th>
              {{-- <th>Delete</th>--}}
             </tr>
           </thead>
           <tbody>
           @if(count($photos))
               @foreach($photos as $photo)
                 <tr>
                   <td><input class="checkboxPhoto" type="checkbox" name="checkboxPhoto[]" value="{{$photo->id}}"></td>
                   <td>{{$photo->id}}</td>
                   <td><img src="{{$photo->file}}" alt=""  class="img-responsive img-rounded" height="50" width="45"></td>
                   <td>{{$photo->created_at}}</td>
                     {{--  <td>
                         <input type="hidden" value="{{$photo->id}}" name="delete_me">
                          <input  type="submit" name="delete_single" value='Delete' class="btn btn-danger">--}}
                         {{--{!! Form::open(['action' => ['AdminMediasController@destroy', $photo->id], 'method' => 'DELETE']) !!}

                               <div class="form-group">
                                 {!! Form::submit('Delete',['class'=>'btn btn-info']) !!}
                               </div>
                           {!! Form::close() !!}
                   </td>--}}
                 </tr>
              @endforeach
            @endif
           </tbody>
         </table>
    </form>
    <div class="col-sm-6 col-sm-offset-3">
        {{$photos->render()}}
    </div>
    @endsection

@section('script')
    <script>
        $(document).ready(function () {

            $('#options').click(function () {
                if(this.checked){

                    $('.checkboxPhoto').each(function () {
                        this.checked = true;
                    })
                }else{
                    $('.checkboxPhoto').each(function () {
                        this.checked = false;
                    })
                }
            });
        });
    </script>

    @endsection