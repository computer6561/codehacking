@extends('layouts.admin')
@section('page-header')
    <span>Edit Users Details</span>
@endsection
@section('content')
    
    <div class="col-sm-3">
        <img src="../../{{$user->photo?$user->photo->file:'http://placehold.io/400x400'}}" alt="" class="img-responsive img-rounded">
        <div class="row">

        </div>
    </div>
     <div class="col-sm-9">

    {!! Form::model($user,['action' => ['AdminUserController@update',$user->id], 'method' => 'patch','files'=>true]) !!}
    <div class="form-group">
        {!! Form::label('name','Name : ') !!}
        {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('email','Email : ') !!}
        {!! Form::email('email',null,['class'=>'form-control','placeholder'=>'enter email']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('role_id','Role : ') !!}
        {!! Form::select('role_id',array(''=>'Choose Options')+$roles,null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('is_active','Status : ') !!}
        {!! Form::select('is_active',array(0=>'Not Active',1=>'Active'),null,['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('password','Password : ') !!}
        {!! Form::password('password',['class'=>'form-control','placeholder'=>'enter password']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('file','Photo : ') !!}
        {!! Form::file('file',['class'=>'form-control','placeholder'=>'title']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Update',['class'=>'btn btn-info col-sm-3']) !!}
    </div>
    {!! Form::close() !!}
         {!! Form::open(['action' => ['AdminUserController@destroy',$user->id ], 'method' => 'DELETE']) !!}

         <div class="form-group text-center">
             {!! Form::submit('Delete',['class'=>'btn btn-danger col-sm-3 col-sm-offset-6']) !!}
         </div>
         {!! Form::close() !!}
    @include('includes.form_errors')
     </div>

@endsection