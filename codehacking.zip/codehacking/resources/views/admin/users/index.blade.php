@extends('layouts.admin')
@section('page-header')
    <span>User Details</span>
    @endsection
@section('content')

     <table class="table table-bordered table-striped table-hover">
         <thead>
         @if(Session::has('deleted_user'))
          <tr>
               <th colspan="8" class="text-danger text-center bg-danger">{{session('deleted_user')}}</th>
           </tr>
         @endif
           <tr>
             <th>Id</th>
             <th>Photo</th>
             <th>Name</th>
             <th>Email</th>
               <th>Role</th>
             <th>Status</th>
             <th>Join on</th>
             <th>Updated</th>
           </tr>
         </thead>
         <tbody>
         @if($users)
            @foreach($users as $user)
           <tr>
             <td>{{$user->id}}</td>
             <td><img src="{{$user->photo?$user->photo->file:'http://placehold.it/100x100'}}" alt="" class="img-responsive img-rounded" height="50" width="45"></td>
             <td><a href="{{route('admin.users.edit',$user->id)}}">{{$user->name}}</a></td>
             <td>{{$user->email}}</td>
               <td>{{$user->role->name}}</td>

             <td>{{$user->is_active?'Active':'Not Active'}}</td>
             <td>{{$user->created_at}}</td>
             <td>{{$user->updated_at->diffForHumans()}}</td>
           </tr>
           @endforeach
         @endif
         </tbody>
       </table>
      <div class="col-sm-6 col-sm-offset-4">
          {{$users->render()}}
      </div>
    @endsection