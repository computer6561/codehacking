@extends('layouts.admin')
@section('page-header')
    Create User
@endsection
@section('content')


       {!! Form::open(['action' => ['AdminUserController@store'], 'method' => 'post','files'=>true]) !!}
             <div class="form-group">
                {!! Form::label('name','Name : ') !!}
                {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']) !!}
             </div>
            <div class="form-group">
                {!! Form::label('email','Email : ') !!}
                {!! Form::email('email',null,['class'=>'form-control','placeholder'=>'enter email']) !!}
             </div>
            <div class="form-group">
                {!! Form::label('role_id','Role : ') !!}
                {!! Form::select('role_id',array(''=>'Choose Options')+$roles,null,['class'=>'form-control']) !!}
             </div>
             <div class="form-group">
                 {!! Form::label('is_active','Status : ') !!}
                 {!! Form::select('is_active',array(0=>'Not Active',1=>'Active'),1,['class'=>'form-control']) !!}
              </div>
               <div class="form-group">
                   {!! Form::label('password','Password : ') !!}
                   {!! Form::password('password',['class'=>'form-control','placeholder'=>'enter password']) !!}
                </div>
             <div class="form-group">
                    {!! Form::label('file','Photo : ') !!}
                    {!! Form::file('file',['class'=>'form-control','placeholder'=>'title']) !!}
             </div>
             <div class="form-group">
               {!! Form::submit('Add User',['class'=>'btn btn-info']) !!}
             </div>
         {!! Form::close() !!}

         @include('includes.form_errors')
    @endsection