@extends('layouts.admin')
@section('page-header')
    <span>User Account Setting</span>
@endsection
@section('content')

    <div class="col-sm-3 text-center">
        <img src="{{$user->photo?$user->photo->file:'http://placehold.it/150x200'}}" alt="" class="img-responsive img-rounded" height="160" width="140">
        <div class="row">

        </div>
    </div>
    <div class="col-sm-9 well">

        {!! Form::model($user,['action' => ['AdminController@updateAccount'], 'method' => 'post','files'=>true]) !!}
        <div class="form-group">
            {!! Form::label('name','Name : ') !!}
            {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('email','Email : ') !!}
            {!! Form::email('email',null,['class'=>'form-control','placeholder'=>'enter email']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('password','Password : ') !!}
            {!! Form::password('password',['class'=>'form-control','placeholder'=>'enter password']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('file','Photo : ') !!}
            {!! Form::file('file',['class'=>'form-control','placeholder'=>'title']) !!}
        </div>
        <div class="form-group text-center">
            {!! Form::submit('Update',['class'=>'btn btn-info col-sm-3']) !!}
        </div>
        {!! Form::close() !!}
        @include('includes.form_errors')
    </div>

@endsection