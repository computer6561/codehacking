@extends('layouts.admin')
@section('page-header')
    <span>Categories</span>
@endsection
@section('content')

    <table class="table table-bordered table-striped table-hover text-center">
        <thead>
        @if(Session::has('deleted_category'))
            <tr>
                <th colspan="8" class="text-danger text-center bg-danger">{{session('deleted_category')}}</th>
            </tr>
        @endif
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Created On</th>
            <th>Updated On</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        @if($categories)
            @foreach($categories as $category)
                <tr>
                    <td>{{$category->id}}</td>
                    <td>{{$category->name}}</td>
                    <td>{{$category->created_at}}</td>
                    <td>{{$category->updated_at->diffForHumans()}}</td>
                    <td>
                        <a href="{{route('admin.categories.edit',$category->id)}}"><i class="fa fa-edit"></i></a>
                    </td>
                    <td>
                         {!! Form::open(['action' => ['AdminCategoriesController@destroy',$category->id], 'method' => 'DELETE']) !!}
                              <div class="form-group">
                                {!! Form::submit('Delete',['class'=>'btn btn-xs btn-danger']) !!}
                              </div>
                          {!! Form::close() !!}
                    </td>
                </tr>
            @endforeach
        @endif
        </tbody>
    </table>
    <div class="col-sm-6 col-sm-offset-4">
        {{$categories->render()}}
    </div>
@endsection