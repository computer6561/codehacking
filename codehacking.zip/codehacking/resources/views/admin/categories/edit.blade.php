@extends('layouts.admin')
@section('page-header')
    Edit Category
@endsection
@section('content')

    <div class="col-sm-10">
        {!! Form::model($category,['action' => ['AdminCategoriesController@update',$category->id], 'method' => 'PATCH']) !!}
        <div class="form-group">
            {!! Form::label('name','Name : ') !!}
            {!! Form::text('name',null,['class'=>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::submit('Update',['class'=>'btn btn-info']) !!}
        </div>
        {!! Form::close() !!}
    </div>


@endsection