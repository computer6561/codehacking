@extends('layouts.admin')
@section('page-header')
    Create Category
@endsection
@section('content')


    {!! Form::open(['action' => ['AdminCategoriesController@store'], 'method' => 'post']) !!}
    <div class="form-group">
        {!! Form::label('name','Name : ') !!}
        {!! Form::text('name',null,['class'=>'form-control','placeholder'=>'enter name']) !!}
    </div>
    <div class="form-group">
        {!! Form::submit('Add Category',['class'=>'btn btn-info']) !!}
    </div>
    {!! Form::close() !!}

    @include('includes.form_errors')
@endsection