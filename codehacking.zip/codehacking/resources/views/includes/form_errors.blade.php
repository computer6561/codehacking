
@if(count($errors)>0)
    <ul  class="alert alert-danger">
        @foreach($errors->all() as $error)
            <li class="danger">
                <em>Ooop!! </em>{{$error}}
            </li>
        @endforeach


    </ul>
@endif
