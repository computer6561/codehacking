<!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">


    <!--Admin Top Header Navigation -->
    @include('includes.admin_top_nav')


    <!-- Admin Sidebar Navigation -->
   {{-- @if(Auth::user()->role->name=='administrator')--}}
      @include('includes.admin_side_nav')
     {{--   @endif--}}
</nav>