<footer>
    <div class="row">
        <div class="col-lg-12">
            <p class="text-center">Udaan &copy; Ramgarh Engineering College 2018</p>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</footer>

<!-- jQuery -->
<script src="js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>