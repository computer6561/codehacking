<?php

namespace App\Http\Controllers;

use App\Http\mail\SocialMail;
use Illuminate\Http\Request;


//Load Composer's autoloader

class SocialMediaCommunications extends Controller
{
        public function sendEmail(){
            $id=array('sunilarangi6561@gmail.com');
            $name = array('Sunil Kumar');
            $message = "
<html>
<body>
<div style='border:1px solid red;width:600px'>
<p><img src='http://hostelsincity.com/assets/img/logo.png'/></p>
<p style='padding-left:10px;'><b>Dear User,</b></p> 
<p style='color:red;'>This is testing email</p>
<a href='http://xyz.com/resetpassword.php' 
style='background:blue;color:#ffffff;'>Click here
</a>
</div>
</body>
</html>
" ;
            $subject='Login Successful';
            $attachments= array();
            $type = 'TO';

            echo  SocialMail::sendEmail($id,$name,$subject,$message,$attachments,$type);
        }
}
