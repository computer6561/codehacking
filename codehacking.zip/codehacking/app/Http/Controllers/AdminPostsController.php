<?php

namespace App\Http\Controllers;

use App\Category;
use App\Http\Requests\PostsCreateRequest;
use App\Photo;
use App\Post;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class AdminPostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::paginate(2);
        return view('admin.posts.index',compact('posts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::pluck('name','id')->all();
        return view('admin.posts.create',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PostsCreateRequest $request)
    {
         $inputs['category_id']= $request->category_id;
         $inputs['title']=$request->title;
         $inputs['body']=$request->body;
        $user = Auth::user();
        $inputs['user_id'] = $user->id;
        if($file = $request->file('photo_id')){
            $name= time().$file->getClientOriginalName();
            $file->move('images',$name);
            $pic_id=Photo::create(['file'=>$name]);
             $inputs['photo_id'] = $pic_id->id;
        }
        echo $inputs['slug'] = str_slug($request->title);
      Post::create($inputs);
       //print_r((object)$inputs);
       return redirect('/admin/posts');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = Category::pluck('name','id')->all();
        $post = Post::findOrFail($id);
        return view('admin.posts.edit',compact('categories','post'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $inputs= $request->all();

        if($file = $request->file('photo_id')){
            $name = time().$file->getClientOriginalName();
            $file->move('images',$name);
              $pic = Post::find($id)->photo;
             // unlink(str_replace('/..','',public_path().'/'.$pic->file));
            if($pic)
                  Photo::find($pic->id)->update(['file'=>$name]);
            else
              $pic= Photo::create(['file'=>$name]);

            $inputs['photo_id'] = $pic->id;
        }
       /* $inputs['slug'] = str_slug('title');*/
        Post::find($id)->update($inputs);
        Session::flash('updated_post','Post has been updated');
        return redirect('admin/posts');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::findOrFail($id);
        Photo::find($post->photo_id)->delete();
        $post->delete();
        Session::flash('deleted_post','The post has been deleted.');
        return redirect('admin/posts');
    }


}
