<?php

namespace App\Http\Controllers;

use App\Category;
use App\Comment;
use App\CommentReply;
use App\Http\Requests\UserSettingRequest;
use App\Photo;
use App\Post;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use vendor\project\StatusTest;

class AdminController extends Controller
{
    public function index(){

        $countPosts = Post::count();
        $countCategories = Category::count();
        $countComments = Comment::count();
        $countCommentReplies = CommentReply::count();
        $countPhotos = Photo::count();
        return view('admin.index',compact('countPosts','countCategories','countComments','countCommentReplies','countPhotos'));
    }
    public function info(){
        if (Auth::check()){
            $myaccount = Auth::user();
        return view('admin.show',compact('myaccount'));
        }else
            return view('/');
    }
    public function setting()
    {

        if(Auth::check()){
            $user = Auth::user();
            return view('admin.setting',compact('user'));
        }



    }
    public function updateAccount(UserSettingRequest $request)
    { //return $id;
        if(Auth::check()){
            $user= Auth::user();
        }
        if($request->password==''){
            $input = $request->except('password');
        }else{
            $input = $request->all();
            $input['password']=bcrypt($request->password);
        }
        if($file =$request->file('file')){
            $name = time().$file->getClientOriginalName();
            $file->move('images',$name);
           if($user->photo_id=='') {
               $pic = Photo::create(array('file' => $name));
               $input['photo_id'] = $pic->id;
           }
           else{
               $id = $user->photo_id;
               Photo::find($id)->update(array('file'=>$name));
           }

        }
        //$input['password'] = trim($request->password)?bcrypt($request->password):$user->password;
        $user->update( $input);
        return redirect('account/info');
    }


}
