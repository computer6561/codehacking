<?php
/**
 * Created by PhpStorm.
 * User: Sunil Kumar
 * Date: 17-08-2018
 * Time: 02:44 AM
 */

namespace App\Http\mail;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class SocialMail
{
    public static function sendEmail($id,$name,$subject,$message,$attachments,$type){

        $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
        try {
            //Server settings
            $mail->SMTPDebug = 0;                                 // Enable verbose debug output
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'projecttesting6561@gmail.com';                 // SMTP username
            $mail->Password = 'Android@1234';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;                                    // TCP port to connect to

            $mail->setFrom('projecttesting6561@gmail.com', 'Udaan Form');
            $mail->addReplyTo('sunilarangi6561@gmail.com', 'Sunil Kumar');
            //Recipients
            if($type=='TO'){
                if(count($id)>0)
                {
                    for($i=0;$i<count($id);$i++)
                    {
                        $mail->addAddress($id[$i],$name[$i]);
                    }
                }
            }else if($type=='BCC'){
                if(count($id)>0)
                {
                    for($i=0;$i<count($id);$i++)
                    {
                        $mail->addBCC($id[$i],$name[$i]);
                    }
                }
                if(count($attachments)){
                    foreach ($attachments as $attachment){
                        $mail->addAttachment($attachment);
                    }
                }
            }


           /* $mail->addAddress('sunilarangi6561@gmail.com', 'Joe User');     // Add a recipient*/
            /* $mail->addAddress('ellen@example.com');               // Name is optional

             $mail->addCC('cc@example.com');
             $mail->addBCC('bcc@example.com');*/

            //Attachments
            /*$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
            $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name*/

            //Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body    = $message;
            $mail->AltBody = 'This is the mail from Udaan Form';

            return $sent = $mail->send();
        } catch (Exception $e) {
            return $mail->ErrorInfo;
        }
    }

}